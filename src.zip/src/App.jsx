import { createBrowserRouter , RouterProvider } from 'react-router-dom' 
import Layout from './layout/layout'
// import Journal from './pages/Journal/Journal'
import Addiction from './pages/Addiction/Addiction'
// import Awareness from './pages/Awareness/Awareness'
// import Home from './pages/Home/Home'
// import Ai from './pages/Ai/Ai'
// import About from './components/About/About'
//import Login from './pages/Auth/login'
//import Register from './pages/Auth/register'
export default function App() {
  const router = createBrowserRouter([
    {
      path : '/',
      element : <Layout/> ,
      children : [
          //  {index : true , element : <Home/>}
          //{index : true , element : <Login/>}
          // {index : true , element : <Register/>}
          // {index : true , element : <About/>}
          // {index : true , element : <Ai/>}
          // {index : true , element : <Journal/>}
          {index : true , element : <Addiction/>}
          // {index : true , element : <Awareness/>}
      ]
    }
  ])
  return <RouterProvider router={router} />
}
