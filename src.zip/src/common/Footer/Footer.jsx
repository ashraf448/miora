import { NavLink } from 'react-router-dom'
import './Footer.css'

export default function Footer() {
  return (
    <footer class="bg-(--color-footer) text-white">
      <div class="px-5 py-10 md:grid-cols-2 w-[90%] mx-auto grid grid-cols-1 lg:grid-cols-4 gap-10">
        <div class="md:col-span-1">
          <h3 class="font-bold text-lg mb-3">ميورا</h3>
          <p class="mt-3 max-w-xs text-xs leading-7 text-white/60">
            مساحة تعليمية داعمة تساعدك على فهم مشاعرك وبناء عادات أكثر توازنًا، خطوة بخطوة.
          </p>
        </div>

        <nav class="md:col-span-1" >
          <h4 class="font-bold text-[16px] mb-3">استكشف</h4>
          <ul class="space-y-2 text-[15px] text-white/60">
            <li><NavLink to={"Awareness"} class="hover:text-white transition-colors duration-200">المحتوى التوعوي</NavLink></li>
            <li><NavLink to={""} class="hover:text-white transition-colors duration-200">تمارين الاسترخاء</NavLink></li>
            <li><NavLink to={"Ai"} class="hover:text-white transition-colors duration-200">التقييمات الذاتية</NavLink></li>
          </ul>
        </nav>

        <nav class="md:col-span-1">
          <h4 class="font-bold text-[16px] mb-3">عن ميورا</h4>
          <ul class="space-y-2 text-[15px] text-white/60">
            <li><NavLink to={"About"} class="hover:text-white transition-colors duration-200">عن المنصة</NavLink></li>
            <li><NavLink  class="hover:text-white transition-colors duration-200">المساعدة و الأسئلة</NavLink></li>
            <li><NavLink  class="hover:text-white transition-colors duration-200">تواصل معنا</NavLink></li>
          </ul>
        </nav>

        <nav class="md:col-span-1">
          <h4 class="font-bold text-[16px] mb-3">الخصوصية</h4>
          <ul class="space-y-2 text-[15px] text-white/60">
            <li><NavLink  class="hover:text-white transition-colors duration-200">سياسة الخصوصية</NavLink></li>
            <li><NavLink  class="hover:text-white transition-colors duration-200">شروط الاستخدام</NavLink></li>
          </ul>
        </nav>
      </div>

      <div class="border-t border-white/10 mx-auto max-w-6xl p-4 text-center text-xs text-white/40">
        <p>© 2025 ميورا. جميع الحقوق محفوظة.</p>
      </div>
    </footer>
  )
}
