import "./Navbar.css";
import background from "../../assets/images/miora.png";
import { NavLink } from "react-router-dom";
import { CgProfile } from "react-icons/cg";
import { FaBars , FaTimes } from "react-icons/fa";
import { useState } from "react";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const linkStyle = ({ isActive }) =>
    `rounded-full px-4 py-2  duration-200 ${
      isActive
        ? "bg-(--color-primary) text-white font-semibold"
        : "hover:bg-(--color-primary) hover:text-white"
    }`;

  const closeMenu = () => setMenuOpen(false);
  return (
    <header className="sticky top-4 z-50 mx-auto max-w-6xl px-4">
      <nav className="relative flex items-center justify-between rounded-full border border-(--color-border) bg-white/85 backdrop-blur-sm px-7 py-3 shadow-(--shadow-header)">
        <NavLink
          to={"/"}
          className="flex items-center font-bold text-(--color-primary)"
        >
          <img
            src={background}
            alt="ميورا"
            className="w-10 h-10 md:w-12 md:h-12"
          />
        </NavLink>

        <ul className="hidden items-center flex-row-reverse gap-2 text-base text-(--color-muted) md:flex">
          <li>
            <NavLink to={"/"} className={linkStyle}>
              الرئيسية
            </NavLink>
          </li>
          <li>
            <NavLink to={"Ai"} className={linkStyle}>
              المساعد الذكي
            </NavLink>
          </li>
          <li>
            <NavLink to={"Awareness"} className={linkStyle}>
              المحتوى التوعوي
            </NavLink>
          </li>
          <li>
            <NavLink to={"Journal"} className={linkStyle}>
              مذكراتي
            </NavLink>
          </li>
        </ul>

        <div className="flex items-center gap-2">
          <p className="text-xl text-(--color-ink) mx-2">مرحبا : أحمد</p>
          <CgProfile className="text-3xl" />
        </div>
        <div className="md:hidden text-2xl cursor-pointer" onClick={() => setMenuOpen(true)}>
          <FaBars />
        </div>
      </nav>


      <div className={`fixed inset-0 bg-black/60 z-50 ${menuOpen ? "block" : "hidden"}`}>
        <div className="md:hidden w-90% h-100% p-5  top-full left-4 right-4 mt-2 z-40 peer-checked: bg-white/90 backdrop-blur-md rounded-2xl border border-(--color-border) shadow-(--shadow-header) overflow-hidden">
        <div className="flex justify-between mb-5">
          <h2 className="font-bold">القائمة</h2>
          <FaTimes className="cursor-pointer" onClick={closeMenu}/>
        </div>
        <ul className="flex flex-col gap-4">
          <li>
            <NavLink
              to={"/"}
              onClick={closeMenu}
              className=" rounded-full px-4 py-2 hover:bg-(--color-primary) hover:text-white duration-200"
            >
              الرئيسية
            </NavLink>
          </li>
          <li>
            <NavLink
              to={"Ai"}
              onClick={closeMenu}
              className=" rounded-full px-4 py-1.5 hover:bg-(--color-primary) hover:text-white duration-200"
            >
              المساعد الذكي
            </NavLink>
          </li>
          <li>
            <NavLink
              to={"Awareness"}
              onClick={closeMenu}
              className=" rounded-full px-4 py-1.5 hover:bg-(--color-primary) hover:text-white duration-200"
            >
              المحتوى التوعوي
            </NavLink>
          </li>
          <li>
            <NavLink
              to={"Journal"}
              onClick={closeMenu}
              className=" rounded-full px-4 py-1.5 hover:bg-(--color-primary) hover:text-white duration-200"
            >
              مذكراتي
            </NavLink>
          </li>
        </ul>
        </div>
      </div>
    </header>
  );
}
