import './About.css'
import { RiShieldCheckLine } from "react-icons/ri";

export default function About() {
  return (
    <main className="mx-auto max-w-6xl px-6 pt-20 pb-24">
      <section
        className="text-center mb-16 relative max-w-3xl mx-auto"
       
      >
       

        <p className="text-(--color-primary) text-[16px] font-semibold mb-4">
          عن ميورا
        </p>
        <h1
          id="hero-title"
          className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-bold leading-[1.2] mb-6 text-(--color-page-heading) max-w-3xl mx-auto"
        >
          لأن فهم نفسك يستحق مساحة آمنة
        </h1>
        <p className="text-(--color-page-muted) text-[17px] leading-[1.6] max-w-2xl mx-auto">
          مشروع تعليمي للعافية النفسية يقدّم معرفة مبسطة وأدوات للتأمل وبناء
          عادات <span className="text-(--color-page-heading)">MIORA</span>{" "}
          واقعية بلغة محترمة وغير وصمية.
        </p>
      </section>

      <section
        className="max-w-2xl mx-auto space-y-12"
       
      >
        

        <article className=" text-end p-5 sm:p-8 rounded-2xl shadow border border-white bg-white">
          <h3 className="text-(--color-page-heading) text-xl sm:text-2xl md:text-[26px] font-bold mb-4">
            ما الذي نقدّمه؟
          </h3>
          <p className="text-(--color-page-body) text-[17px] leading-[1.8] ">
            مشروع تعليمي للعافية النفسية يقدّم معرفة مبسطة وأدوات للتأمل وبناء
            عادات واقعية بلغة{" "}
            <span className="text-(--color-page-heading)">MIORA</span> محترمة
            وغير وصمية.
          </p>
        </article>

        <article className=" text-end p-5 sm:p-8 rounded-2xl shadow border border-white bg-white">
          <h3 className="text-(--color-page-heading) text-xl sm:text-2xl md:text-[26px] font-bold mb-4 ">
            التزامنا
          </h3>
          <p className="text-(--color-page-body) text-[17px] leading-[1.8] ">
            نستخدم لغة داعمة ونبتعد عن الوصم والادعاءات الطبية غير الموثقة. نوضح
            دائمًا حدود النموذج والميزات التي تحتاج إلى خدمة خلفية قبل الإطلاق.
          </p>
        </article>
      </section>

      <section className="max-w-2xl mx-auto mt-12" aria-labelledby="notice-title">
        <div
          className="rounded-2xl shadow border border-white bg-white p-6 relative"
         
        >
          <div className="flex flex-row-reverse  items-start  text-end gap-4">
            
              
              <RiShieldCheckLine className="text-4xl text-(--color-primary)" />
              <p className="text-(--color-page-text) text-[16px] leading-[1.8] ">
                هذا المحتوى مؤقت ومخصّص للنموذج الأولي، ويحتاج إلى مراجعة متخصصة
                وقانونية قبل الاستخدام العام.
              </p>
          </div>
        </div>
      </section>
    </main>
  )
}
