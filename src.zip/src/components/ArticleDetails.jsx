
import { Link, useParams } from "react-router-dom";
import { articles } from "../data/articles";

export default function ArticleDetails() {
  const { id } = useParams();

  const article = articles.find((item) => item.id === id);

  if (!article) {
    return (
      <main dir="rtl" className="container mx-auto px-6 py-24 text-center">
        <h1 className="text-3xl font-bold text-(--color-ink)">
          المقال غير موجود
        </h1>

        <p className="mt-4 text-(--color-muted)">
          ربما تم حذف المقال أو أن الرابط غير صحيح.
        </p>

        <Link
          to="/awareness"
          className="mt-6 inline-block rounded-full bg-(--color-primary) px-6 py-3 font-bold text-white"
        >
          العودة للمحتوى التوعوي
        </Link>
      </main>
    );
  }

  return (
    <main dir="rtl" className="container mx-auto px-6 py-12">
      {/* Back */}
      <Link
        to="/awareness"
        className="inline-flex items-center gap-2 font-bold text-(--color-primary)"
      >
        <span>→</span>
        العودة إلى المقالات
      </Link>

      {/* Article Header */}
      <header className="mx-auto mt-10 max-w-4xl text-center">
        <span className="inline-block rounded-full bg-(--color-primary-soft) px-5 py-2 text-sm font-bold text-(--color-primary)">
          {article.category}
        </span>

        <h1 className="mt-6 text-3xl font-bold leading-relaxed text-(--color-ink) md:text-5xl">
          {article.title}
        </h1>

        <p className="mt-5 text-lg leading-8 text-(--color-muted)">
          {article.description}
        </p>

        <p className="mt-5 text-sm text-(--color-muted)">
          ◷ {article.readTime} دقائق قراءة
        </p>
      </header>

      {/* Article Image */}
      {article.image && (
        <div className="mx-auto mt-10 max-w-4xl overflow-hidden rounded-3xl">
          <img
            src={article.image}
            alt={article.title}
            className="max-h-120 w-full object-cover"
          />
        </div>
      )}

      {/* Article Content */}
      <article className="mx-auto mt-12 max-w-3xl">
        {article.content.map((section, index) => (
          <section key={index} className="mb-10">
            <h2 className="mb-5 text-2xl font-bold text-(--color-primary)">
              {section.heading}
            </h2>

            {section.paragraphs.map((paragraph, paragraphIndex) => (
              <p
                key={paragraphIndex}
                className="mb-4 text-lg leading-9 text-(--color-ink)"
              >
                {paragraph}
              </p>
            ))}
          </section>
        ))}
      </article>

      {/* Footer */}
      <div className="mx-auto mt-14 max-w-3xl rounded-2xl bg-(--color-primary-soft) p-7 text-center">
        <h3 className="text-xl font-bold text-(--color-primary)">
          خذ وقتك، وابدأ بالخطوة المناسبة لك
        </h3>

        <p className="mt-3 leading-7 text-(--color-muted)">
          المعرفة بداية جيدة، ولا تحتاج إلى تغيير كل شيء دفعة واحدة.
        </p>

        <Link
          to="/awareness"
          className="mt-5 inline-block rounded-full bg-(--color-primary) px-6 py-3 font-bold text-white transition hover:opacity-90"
        >
          اكتشف المزيد من المقالات
        </Link>
      </div>
    </main>
  );
}
