import { useState } from "react";
import "./Ai.css";
import { LuLeaf } from "react-icons/lu";
import { FaArrowLeftLong } from "react-icons/fa6";

export default function Ai() {
  const [message, setMessage] = useState("");

  const [messages, setMessages] = useState([]);

  const questions = [
    "إزاي أتعامل مع التوتر؟",
    "عايز أفهم مشاعري بشكل أفضل.",
    "إيه العادات اللي ممكن تساعدني أنام بشكل أفضل؟",
    "إزاي أطلب الدعم لما أحتاجه؟",
  ];

  const handleQuestion = (question) => {
    setMessage(question);
  };

  const handleSend = (e) => {
    e.preventDefault();

    if (!message.trim()) return;

    setMessages((prev) => [...prev, message.trim()]);

    setMessage("");
  };
  return (
    <main class="mx-auto Ai  container px-4 py-8">
      <section
        class="  grid  overflow-hidden rounded-3xl bg-(--color-surface) shadow-(--shadow-card) md:grid-cols-[minmax(0,1fr)_260px] "
        dir="ltr"
        aria-label="المساعد الذكي"
      >
        <div class="flex flex-col">
          <div class="flex items-center justify-between border-b border-(--color-border) px-6 py-4 text-sm">
            <h2 class="font-bold">مساحة للحوار</h2>
            <a
              href="#"
              class="font-medium text-(--color-primary) hover:underline"
            >
              المساعدة والدعم
            </a>
          </div>

          <div class="flex  flex-col items-center justify-center px-6 py-10 text-center">
            <LuLeaf />

            <h3 class="mt-5 text-5xl font-bold">أهلًا، أنا هنا لأسمعك</h3>
            <p class="mt-4  text-base leading-7 text-(--color-muted)">
              أنا هنا لمساعدتك على فهم مشاعرك واستكشاف خطوات صحية للتعامل معها.
              يمكنك البدء بالحديث عمّا يشغلك.
            </p>

            <ul className="mt-8 grid w-full gap-3 p-4 sm:grid-cols-2">
              {questions.map((question, index) => (
                <li key={index}>
                  <button
                    type="button"
                    onClick={() => handleQuestion(question)}
                    className="flex w-full items-center justify-between gap-3 rounded-xl border border-(--color-border) bg-(--color-background) px-4 py-4 text-end text-base transition hover-lift hover:border-(--color-primary) hover:text-(--color-primary)"
                  >
                    <FaArrowLeftLong className="shrink-0" />

                    <span>{question}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <form
            onSubmit={handleSend}
            className="flex items-end gap-4 border-t border-(--color-border) px-6 py-5"
            dir="rtl"
          >
            <div className="flex-1">
              <label
                htmlFor="chat-message"
                className="block text-base text-(--color-muted)"
              >
                اكتب ما يدور في بالك
              </label>

              <textarea
                id="chat-message"
                rows="2"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="اكتب رسالتك هنا..."
                className="mt-2 w-full resize-none rounded-lg bg-(--color-background) p-3 text-base outline-none placeholder:text-(--color-muted) focus:ring-1 focus:ring-(--color-primary)"
              />
            </div>

            <button
              type="submit"
              disabled={!message.trim()}
              className="flex shrink-0 items-center gap-2 rounded-xl bg-(--color-primary) px-5 py-3 text-base font-medium text-white shadow-(--shadow-lift) transition hover:bg-(--color-primary-dark) disabled:pointer-events-none disabled:opacity-40"
            >
              إرسال
              <FaArrowLeftLong />
            </button>
          </form>
        </div>

        <aside dir="rtl" className="bg-(--color-sidebar) p-6 text-white">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/10">
            <LuLeaf />
          </span>

          <h1 className="mt-6 text-lg font-bold">مساعد ميورا</h1>

          <p className="mt-3 text-base leading-6 text-white/70">
            واجهة تجريبية لتنظيم الأفكار واستكشاف خطوات عامة.
          </p>

          <button
            type="button"
            onClick={() => {
              setMessages([]);
              setMessage("");
            }}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-base font-medium transition hover:bg-white/20"
          >
            محادثة جديدة
          </button>
        </aside>
      </section>
    </main>
  );
}
