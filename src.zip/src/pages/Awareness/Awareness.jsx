// import './Awareness.css'
// import { IoSearch } from "react-icons/io5";
// export default function Awareness() {
//   return (
//     <main>
//     <section className="mx-auto container px-6 pb-10 pt-16 text-center">
//       <p className="text-2xl font-bold text-(--color-primary)">المحتوى التوعوي</p>
//       <h1 className="mt-5 text-6xl font-bold leading-tight">معرفة بسيطة، أثرها يمتد</h1>
//       <p className="mx-auto mt-5 text-2xl leading-8 text-(--color-muted)">اقرأ في وقتك، وخذ من كل موضوع ما يناسب لحظتك دون ضغط.</p>

//       <div className="mx-auto w-[50%] mt-10">
//         <label className="flex items-center gap-3 rounded-full border border-(--color-border) bg-(--color-surface) px-5 py-3.5 shadow-(--shadow-card)">
//           <IoSearch />
//           <input type="search" placeholder="ابحث عن موضوع أو كلمة..." className="w-full bg-transparent text-lg outline-none placeholder:text-(--color-muted)" />
//         </label>
//       </div>

//     </section>

//     <section className="mx-auto container grid grid-cols-6 gap-6 px-6 pb-24" aria-label="المحتوى حسب التصنيف">
//       <input className="peer/all sr-only" type="radio" name="content-category" id="content-filter-all" checked />
//       <input className="peer/reflection sr-only" type="radio" name="content-category" id="content-filter-reflection" />
//       <input className="peer/sleep sr-only" type="radio" name="content-category" id="content-filter-sleep" />
//       <input className="peer/coping sr-only" type="radio" name="content-category" id="content-filter-coping" />
//       <input className="peer/stress sr-only" type="radio" name="content-category" id="content-filter-stress" />
//       <input className="peer/emotions sr-only" type="radio" name="content-category" id="content-filter-emotions" />

//       <label for="content-filter-emotions" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/emotions:border-transparent peer-checked/emotions:bg-(--color-primary) peer-checked/emotions:text-white peer-focus-visible/emotions:ring-2 peer-focus-visible/emotions:ring-(--color-primary) sm:col-span-2 lg:col-span-1">فهم المشاعر</label>
//       <label for="content-filter-stress" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/stress:border-transparent peer-checked/stress:bg-(--color-primary) peer-checked/stress:text-white peer-focus-visible/stress:ring-2 peer-focus-visible/stress:ring-(--color-primary) sm:col-span-2 lg:col-span-1">التوتر والضغط النفسي</label>
//       <label for="content-filter-coping" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/coping:border-transparent peer-checked/coping:bg-(--color-primary) peer-checked/coping:text-white peer-focus-visible/coping:ring-2 peer-focus-visible/coping:ring-(--color-primary) sm:col-span-2 lg:col-span-1">مهارات التعامل</label>
//       <label for="content-filter-sleep" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/sleep:border-transparent peer-checked/sleep:bg-(--color-primary) peer-checked/sleep:text-white peer-focus-visible/sleep:ring-2 peer-focus-visible/sleep:ring-(--color-primary) sm:col-span-2 lg:col-span-1">النوم والراحة</label>
//       <label for="content-filter-reflection" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/reflection:border-transparent peer-checked/reflection:bg-(--color-primary) peer-checked/reflection:text-white peer-focus-visible/reflection:ring-2 peer-focus-visible/reflection:ring-(--color-primary) sm:col-span-2 lg:col-span-1">التأمل الذاتي</label>
//       <label for="content-filter-all" className="col-span-3 mt-6 justify-self-center cursor-pointer rounded-full border border-(--color-border) bg-(--color-surface) px-4 py-2 text-center text-lg text-(--color-primary-dark) transition hover:border-(--color-primary) peer-checked/all:border-transparent peer-checked/all:bg-(--color-primary) peer-checked/all:text-white peer-focus-visible/all:ring-2 peer-focus-visible/all:ring-(--color-primary) sm:col-span-2 lg:col-span-1">الكل</label>

//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="" alt="تسمية المشاعر: خطوة أولى لفهم نفسك" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">فهم المشاعر</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>4 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">تسمية المشاعر: خطوة أولى لفهم نفسك</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">حين نعطي شعورنا اسمًا، يصبح التعامل معه أوضح وأقل إرباكًا.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/مساحة هادئة وسط ضغط اليوم.jpg" alt="مساحة هادئة وسط ضغط اليوم" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">التوتر والضغط النفسي</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>5 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">مساحة هادئة وسط ضغط اليوم</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">خطوات عملية قصيرة تساعدك على تهدئة إيقاع يوم مزدحم.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/التنفس الواعي في ثلاث دقائق.jpg" alt="التنفس الواعي في ثلاث دقائق" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">مهارات التعامل</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>6 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">التنفس الواعي في ثلاث دقائق</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">تمرين بسيط يمكنك استخدامه عندما تحتاج إلى لحظة توقف.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/روتين مسائي يدعم راحتك.jpg" alt="روتين مسائي يدعم راحتك" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">النوم والراحة</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>7 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">روتين مسائي يدعم راحتك</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">تغييرات واقعية تهيّئ جسمك وذهنك للراحة دون مثالية.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/لماذا تساعدنا الكتابة على التأمل؟.jpg" alt="لماذا تساعدنا الكتابة على التأمل؟" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">التأمل الذاتي</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>4 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">لماذا تساعدنا الكتابة على التأمل؟</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">استخدم الورق لترتيب أفكارك بلا حكم أو ضغط.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/عادات صغيرة يمكن الاستمرار عليها.jpg" alt="عادات صغيرة يمكن الاستمرار عليها" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">العادات الصحية</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>5 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">عادات صغيرة يمكن الاستمرار عليها</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">ابدأ بخطوة تناسب يومك بدل مطاردة تغيير كبير ومفاجئ.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/فهم الرغبة الملحة دون مقاومتها بعنف.jpg" alt="فهم الرغبة الملحة دون مقاومتها بعنف" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">الوعي بالإدمان</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>6 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">فهم الرغبة الملحة دون مقاومتها بعنف</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">تعلّم ملاحظة الرغبة وعبورها بخطوات آمنة وغير وصمية.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/الوعي بالإدمان يبدأ بالتعاطف.jpg" alt="الوعي بالإدمان يبدأ بالتعاطف" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">الوعي بالإدمان</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>7 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">الوعي بالإدمان يبدأ بالتعاطف</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">لغة محترمة ومعلومات هادئة تساعد على الوقاية وطلب الدعم.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/كيف تؤثر الضغوط في عاداتنا؟.jpg" alt="كيف تؤثر الضغوط في عاداتنا؟" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">التوتر والضغط النفسي</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>4 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">كيف تؤثر الضغوط في عاداتنا؟</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">لاحظ الرابط بين المواقف الصعبة والسلوك المتكرر بهدوء.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/الحدود الصحية ليست أنانية.jpg" alt="الحدود الصحية ليست أنانية" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">العلاقات</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>5 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">الحدود الصحية ليست أنانية</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">طرق واضحة ومحترمة للتعبير عن احتياجاتك في العلاقات.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/كيف تطلب الدعم عندما تحتاجه؟.jpg" alt="كيف تطلب الدعم عندما تحتاجه؟" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">طلب المساعدة</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>6 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">كيف تطلب الدعم عندما تحتاجه؟</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">خطوات صغيرة لبدء حديث صادق مع شخص تثق به.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//         <article className="col-span-6 sm:col-span-3 lg:col-span-2 peer-checked/reflection:hidden peer-checked/sleep:hidden peer-checked/coping:hidden peer-checked/stress:hidden peer-checked/emotions:hidden hover-lift overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
//           <div className="relative aspect-video overflow-hidden">
//             <img src="img/التعثّر لا يلغي التقدّم.jpg" alt="التعثّر لا يلغي التقدّم" className="hover-zoom h-full w-full object-cover" loading="lazy" />
//             <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-base font-bold text-(--color-primary-dark)">تغيير العادات</span>
//           </div>
//           <div className="p-5">
//             <p className="flex items-center gap-1.5 text-2xl text-(--color-muted)"><svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>7 دقائق قراءة</p>
//             <h3 className="mt-3 text-2xl font-bold leading-snug">التعثّر لا يلغي التقدّم</h3>
//             <p className="mt-2 text-lg leading-7 text-(--color-muted)">نظرة واقعية للانتكاسات وكيفية العودة بخطة أكثر لطفًا.</p>
//             <a href="#" className="mt-3 inline-flex items-center gap-1.5 text-lg font-bold text-(--color-primary)">اقرأ المقال <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
//           </div>
//         </article>
//     </section>
//   </main> 
//   )
// }



import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { IoSearch } from "react-icons/io5";
import { articles } from "../../data/articles";

const categories = [
  "الكل",
  ...new Set(articles.map((article) => article.category)),
];

export default function Awareness() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("الكل");

  const filteredArticles = useMemo(() => {
    const searchValue = search.trim().toLowerCase();

    return articles.filter((article) => {
      const matchesCategory =
        activeCategory === "الكل" ||
        article.category === activeCategory;

      const searchableText = [
        article.title,
        article.description,
        article.category,
      ]
        .join(" ")
        .toLowerCase();

      const matchesSearch = searchableText.includes(searchValue);

      return matchesCategory && matchesSearch;
    });
  }, [search, activeCategory]);

  return (
    <main dir="rtl">
      {/* Hero */}
      <section className="container mx-auto px-6 pb-10 pt-16 text-center">
        <p className="text-2xl font-bold text-(--color-primary)">
          المحتوى التوعوي
        </p>

        <h1 className="mt-5 text-4xl font-bold leading-tight md:text-6xl">
          معرفة بسيطة، أثرها يمتد
        </h1>

        <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-(--color-muted) md:text-2xl">
          اقرأ في وقتك، وخذ من كل موضوع ما يناسب لحظتك دون ضغط.
        </p>

        {/* Search */}
        <div className="mx-auto mt-10 w-full max-w-2xl">
          <label className="flex items-center gap-3 rounded-full border border-(--color-border) bg-(--color-surface) px-5 py-3.5 shadow-(--shadow-card)">
            <IoSearch className="shrink-0 text-xl text-(--color-muted)" />

            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن موضوع أو كلمة..."
              className="w-full bg-transparent text-xl outline-none placeholder:text-(--color-muted)"
            />

            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="text-base text-(--color-muted) transition hover:text-(--color-primary)"
              >
                مسح
              </button>
            )}
          </label>
        </div>
      </section>

      <section className="container mx-auto px-6 pb-24">
        <div className="mb-10 flex flex-wrap justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setActiveCategory(category)}
              className={`rounded-full border px-5 py-2.5 text-lg transition ${
                activeCategory === category
                  ? "border-transparent bg-(--color-primary) text-white"
                  : "border-(--color-border) bg-(--color-surface) text-(--color-primary-dark) hover:border-(--color-primary)"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Results count */}
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-xl font-bold text-(--color-ink)">
            المقالات التوعوية
          </h2>

          <p className="text-sm text-(--color-muted)">
            {filteredArticles.length} مقال
          </p>
        </div>

        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredArticles.map((article) => (
              <article
                key={article.id}
                className="group overflow-hidden rounded-2xl border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card) transition duration-300 hover:-translate-y-1 hover:shadow-(--shadow-lift)"
              >
                {/* Image */}
                <div className="relative aspect-video overflow-hidden bg-(--color-primary-soft)">
                  {article.image ? (
                    <img
                      src={article.image}
                      alt={article.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-(--color-primary)">
                      <span className="text-5xl">🌿</span>
                    </div>
                  )}

                  <span className="absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-lg font-bold text-(--color-primary-dark)">
                    {article.category}
                  </span>
                </div>

                {/* Content */}
                <div className="p-5">
                  <p className="text-base text-(--color-muted)">
                    ◷ {article.readTime} دقائق قراءة
                  </p>

                  <h3 className="mt-3 text-2xl font-bold leading-snug text-(--color-ink)">
                    {article.title}
                  </h3>

                  <p className="mt-2 line-clamp-2 text-lg leading-7 text-(--color-muted)">
                    {article.description}
                  </p>

                  <Link
                    to={`/awareness/${article.id}`}
                    className="mt-5 inline-flex items-center gap-2 font-bold text-(--color-primary) transition hover:gap-3"
                  >
                    اقرأ المقال
                    <span aria-hidden="true">←</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="rounded-2xl border border-(--color-border) bg-(--color-surface) px-5 py-16 text-center">
            <div className="mb-4 text-5xl">🔎</div>

            <h3 className="text-xl font-bold text-(--color-ink)">
              لم نعثر على مقالات
            </h3>

            <p className="mt-3 text-(--color-muted)">
              جرّب كلمة بحث مختلفة أو اختر تصنيفًا آخر.
            </p>

            <button
              type="button"
              onClick={() => {
                setSearch("");
                setActiveCategory("الكل");
              }}
              className="mt-6 rounded-full bg-(--color-primary) px-6 py-3 font-bold text-white transition hover:opacity-90"
            >
              عرض كل المقالات
            </button>
          </div>
        )}
      </section>
    </main>
  );
}
