
// export default function Register() {
//   return (
//     <div className="min-h-screen flex items-center flex-col justify-center p-2.5">
//         <form action=""  className="bg-white gap-1.5 flex items-center flex-col justify-center p-6 sm:p-10 rounded-2xl shadow-lg w-full max-w-112.5">
//             <p className="text-3xl py-3 text-center">أنشئ مساحتك</p>
//             <p>ابدأ بخطوات بسيطة,ومن دون معلومات حساسة</p>
//             <label htmlFor="" className="text-end w-full">الاسم</label>
//             <input type="email" className="rounded-xl w-full p-2 bg-gray-200" placeholder="اسمك الأول" />
//             <label htmlFor="" className="text-end w-full">البريد الالكتروني</label>
//             <input type="email" className="rounded-xl w-full p-2 bg-gray-200" placeholder="name@example.com" />
//             <label htmlFor="" className="text-end w-full"> رقم الهاتف</label>
//             <input type="number" className="rounded-xl w-full p-2 bg-gray-200" placeholder="" />
//             <label htmlFor="" className="text-end w-full">العمر</label>
//             <input type="number" className="rounded-xl w-full p-2 bg-gray-200" placeholder="" />
//             <label htmlFor="" className="text-end w-full">كلمة المرور</label>
//             <input type="password" className="rounded-xl w-full p-2 bg-gray-200" placeholder="8 أحرف على الأقل" />
//             <label htmlFor="" className="text-end w-full">تأكيد كلمة المرور</label>
//             <input type="password" className="rounded-xl w-full p-2 bg-gray-200" placeholder="8 أحرف على الأقل" />
//             <button type="submit" className="bg-blue-500 w-full rounded-xl p-2 m-2">تسجيل الدخول</button>
            
//         </form>
//     </div>
//   )
// }


import { useState } from "react";
import {
  TextField,
  Button,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  InputLabel,
  Radio,
  OutlinedInput,
  InputAdornment,
  IconButton,
  Typography,
} from "@mui/material";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { NavLink , useNavigate} from "react-router-dom";
import { useForm } from "react-hook-form"; 
import { zodResolver } from "@hookform/resolvers/zod";
import registerSchema from "../../validations/registerValidation";
import useAuth from '../../zustand/AuthSlice'
import toast from 'react-hot-toast'
export default function Register() {
  const { register, handleSubmit, formState: { errors },
  } = useForm({
    resolver: zodResolver(registerSchema),
    mode :'all'
  });

  const navigate = useNavigate()
  const registerHandler =useAuth ( s=>s.registerHandler)
  const [showPassword, setShowPassword] = useState(false);
  const [err, setErr] = useState(null);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const onSubmit =async (data) => {
   const res =await registerHandler(data);
    if (res.success) {
        setErr(null)
        navigate('/')
        scrollTo({top:0})
        toast.success("Success SignUp")
    }else{
        setErr(res.message)
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-2">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-white p-6 sm:p-10 rounded-2xl shadow-lg w-full max-w-112.5"
      >
        <Typography variant="h4" textAlign="center" mb={3} fontWeight="bold">
          أنشئ مساحتك
        </Typography>
        <Typography textAlign="end" mt={2}>
          ابدأ بخطوات بسيطة,ومن دون معلومات حساسة
        </Typography>

        {/* First + Last Name */}
        <div className="flex gap-2 mb-2">
          <TextField
            label="الاسم الأول"
            fullWidth
            {...register("firstName")}
            error={!!errors.firstName}
            helperText={errors.firstName?.message}
          />
          <TextField
            label="الاسم الأخير"
            fullWidth
            {...register("lastName")}
            error={!!errors.lastName}
            helperText={errors.lastName?.message}
          />
        </div>

        {/* Email */}
        <TextField
          label="البريد الالكتروني"
          fullWidth
          margin="normal"
          {...register("email")}
          error={!!errors.email}
          helperText={errors.email?.message}
        />

        {/* Phone */}
        <TextField
          label="رقم الهاتف"
          fullWidth
          margin="normal"
          {...register("phone")}
          error={!!errors.phone}
          helperText={errors.phone?.message}
        />


        {/* Password */}
        <FormControl fullWidth margin="normal">
          <InputLabel>كلمة المرور</InputLabel>
          <OutlinedInput
            type={showPassword ? "text" : "password"}
            {...register("password")}
            endAdornment={
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
          <p className="text-red-500 text-sm">
            {errors.password?.message}
          </p>
        </FormControl>

        {/* Confirm Password */}
        <FormControl fullWidth margin="normal">
          <InputLabel>تأكيد كلمة المرور</InputLabel>
          <OutlinedInput
            type={showConfirmPassword ? "text" : "password"}
            {...register("confirmPassword")}
            endAdornment={
              <InputAdornment position="end">
                <IconButton onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                  {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
                </IconButton>
              </InputAdornment>
            }
            label="Confirm Password"
          />
          <p className="text-red-500 text-sm">
            {errors.confirmPassword?.message}
          </p>
        </FormControl>


        {/* Gender */}

        <FormControl margin="normal">
          <FormLabel>الجنس</FormLabel>
          <RadioGroup row {...register("gender")}>
            <FormControlLabel value="ذكر" control={<Radio />} label="ذكر" />
            <FormControlLabel value="أنثى" control={<Radio />} label="أنثى" />
          </RadioGroup>
          <p className="text-red-500 text-sm">
            {errors.gender?.message}
          </p>
        </FormControl>
            {
                err &&
                <div className="bg-red-100 text-red-700 text-center rounded shadow">{err}</div>
            }
        <Button type="submit" variant="contained" fullWidth sx={{ mt: 2 }}>
          تسجيل الدخول
        </Button>

        <Typography textAlign="center" mt={2}>
          هل لديك حساب بالفعل؟{" "}
          <NavLink to="/login" style={{ color: "#1976d2", fontWeight: "bold" }}>
            سجّل الدخول
          </NavLink>
        </Typography>
        
      </form>
    </div>
  );
}