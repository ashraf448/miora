import "./Home.css";
import { useState } from "react";
import {FaCheck , FaWind , FaArrowLeftLong } from "react-icons/fa6";
import { PiChatBold } from "react-icons/pi";
import { FaRegHeart } from "react-icons/fa";
import { MdOutlineDarkMode } from "react-icons/md";
import { LuLeaf } from "react-icons/lu";
import image1 from "../../assets/images/hero.jpg";

export default function Home() {
  const moods = [
    { id: "unsure", label: "مش عارف" },
    { id: "tired", label: "مرهق" },
    { id: "sad", label: "حزين" },
    { id: "anxious", label: "قلقان" },
    { id: "tense", label: "متوتر" },
    { id: "hopeful", label: "متفائل" },
    { id: "calm", label: "هادي" },
    { id: "happy", label: "مبسوط" },
  ];

  const [selectedMood, setSelectedMood] = useState(null);

  const selectedMoodData = moods.find((mood) => mood.id === selectedMood);
  return (
    <main className="Home">
      <section className="mx-auto grid container items-center gap-12 px-6 pb-24 pt-16 md:grid-cols-2">
        <div className="relative mx-auto w-full max-w-md">
          <div className="hero-arch animate-arch-in aspect-3/4 overflow-hidden bg-(--color-primary-soft) shadow-(--shadow-card)">
            <img src={image1} alt="" className="h-full w-full object-cover" />
          </div>

          <div className="animate-float absolute -inset-s-4 top-4 grid h-25 w-25 place-items-center rounded-full bg-(--color-primary-soft) p-2 text-center text-sm font-medium text-(--color-primary) shadow-(--shadow-card)">
            خد نفس هادي
          </div>

          <div className="animate-float absolute -inset-e-6 bottom-16 rounded-xl bg-white/90 px-4 py-3 shadow-(--shadow-card)">
            <div className="flex items-center gap-2 text-xl font-semibold">
              <span className="animate-pulse-dot h-2 w-2 rounded-full bg-green-500"></span>
              لحظة لنفسك
            </div>
            <p className="mt-1 text-[14px] text-(--color-muted)">
              ابدأ بما تشعر به الآن
            </p>
          </div>

          <a className="absolute -inset-s-6 bottom-6 inline-flex items-center gap-2 rounded-full bg-(--color-primary) px-4 py-2 text-lg text-white shadow-(--shadow-card) transition hover:bg-(--color-primary-dark)">
            <PiChatBold />
            تحدث معنا
          </a>
        </div>

        <div className="text-end max-w-[90%]">
          <p className=" mb-4 text-lg font-bold text-(--color-primary)">
            مساحة هادئة، خطوة حقيقية.
          </p>
          <h1 className=" text-6xl w-70% font-bold leading-tight md:text-6xl">
            مساحة آمنة تبدأ منها رحلة فهم نفسك
          </h1>
          <p className=" mt-6 text-xl leading-8 text-(--color-muted)">
            افهم مشاعرك، اكتشف طرقًا صحية للتعامل مع الضغوط، وخد خطوات صغيرة نحو
            حياة أكثر توازنًا.
          </p>
          <a className=" mt-8 inline-flex items-center gap-2 rounded-xl bg-(--color-primary) px-6 py-3 text-lg font-medium text-white transition hover:bg-(--color-primary-dark)">
            <FaArrowLeftLong />
            استكشف المنصة
          </a>
        </div>
      </section>

      <section className="bg-(--color-surface) py-20">
        <div className="mx-auto container px-5">
          <p className="text-base text-end font-bold text-(--color-primary)">
            تسجيل شعورك
          </p>
          <h2 className="mt-3 text-end text-5xl font-bold ">
            حاسس بإيه النهارده؟
          </h2>
          <p className="mt-3 text-end text-xl text-(--color-muted)">
            اختار الأقرب لك، من غير ما تحتاج تبرر أو تغير شعورك.
          </p>

          <div>
            <ul className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-8">
              {moods.map((mood) => (
                <li key={mood.id}>
                  <input
                    type="radio"
                    id={`mood-${mood.id}`}
                    name="mood"
                    value={mood.id}
                    checked={selectedMood === mood.id}
                    onChange={() => setSelectedMood(mood.id)}
                    className="peer sr-only"
                  />

                  <label
                    htmlFor={`mood-${mood.id}`}
                    className={`relative flex w-full cursor-pointer flex-col items-center gap-3 rounded-2xl border px-3 py-5 text-xl font-medium transition-all duration-300 hover:-translate-y-1
          ${
            selectedMood === mood.id
              ? "border-(--color-primary) bg-(--color-primary-soft) text-(--color-primary)"
              : "border-(--color-border) bg-(--color-background)"
          }`}
                  >
                    {/* Check Icon */}
                    <span
                      className={`absolute inset-s-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-(--color-primary) text-white transition ${
                        selectedMood === mood.id
                          ? "scale-100 opacity-100"
                          : "scale-75 opacity-0"
                      }`}
                    >
                      <FaCheck />
                    </span>

                    {/* Mood Icon */}
                    <span className="grid h-12 w-12 place-items-center rounded-full bg-white text-(--color-primary)">
                      {mood.id === "happy" && "☀️"}
                      {mood.id === "calm" && "🍃"}
                      {mood.id === "hopeful" && "✨"}
                      {mood.id === "tense" && "💨"}
                      {mood.id === "anxious" && "⚠️"}
                      {mood.id === "sad" && "♡"}
                      {mood.id === "tired" && "🌙"}
                      {mood.id === "unsure" && "💬"}
                    </span>

                    {mood.label}
                  </label>
                </li>
              ))}
            </ul>

            {selectedMoodData && (
              <div
                className="mt-8 flex flex-col gap-5 rounded-2xl bg-[color-mix(in_srgb,var(--color-primary)_60%,white)] p-6 text-white animate-arch-in md:flex-row md:items-center md:justify-between"
                role="status"
              >
                <div className="flex items-start gap-3">
                  <FaRegHeart />

                  <div>
                    <p className="font-bold text-lg">شكرًا لأنك لاحظت شعورك.</p>

                    <p className="mt-2 text-lg leading-7">
                      كونك{" "}
                      <strong className="font-bold">
                        {selectedMoodData.label}
                      </strong>{" "}
                      الآن هو جزء من يومك، وليس تعريفًا لك. يمكنك كتابة ما يدور
                      بداخلك أو تجربة تمرين قصير.
                    </p>
                  </div>
                </div>

                <a
                  href="/journal"
                  className="shrink-0 rounded-xl bg-white px-6 py-3 text-center text-lg font-bold text-black shadow transition hover:bg-(--color-primary-soft)"
                >
                  اكتب في مذكراتك
                </a>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="mx-auto container px-6 py-16">
        <div className="relative overflow-hidden rounded-3xl bg-(--color-primary) px-8 py-20 text-white md:px-14">
          <div className="pointer-events-none absolute -bottom-36 -inset-s-18 h-64 w-64 rounded-full bg-white/5"></div>

          <div className="relative grid items-center gap-10 md:grid-cols-2">
            <ol className="flex flex-row-reverse items-start justify-between gap-4 text-center text-base">
              <li className="flex flex-col items-center gap-2">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-white/15 text-base font-semibold">
                  1
                </span>
                اختار الوجهة
              </li>
              <li
                className="mt-5 h-px flex-1 bg-white/25"
                
              ></li>
              <li className="flex flex-col items-center gap-2">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-white/15 text-base font-semibold">
                  2
                </span>
                اعرف ما نقدمه
              </li>
              <li
                className="mt-5 h-px flex-1 bg-white/25"
                
              ></li>
              <li className="flex flex-col items-center gap-2">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-white/15 text-base font-semibold">
                  3
                </span>
                ابدأ بخطواتك
              </li>
            </ol>
            <div className="text-end">
              <p className="text-base text-white/70">أدوات تناسب لحظتك</p>
              <h2 className="mt-3 text-5xl font-bold">مش عارف تبدأ منين؟</h2>
              <p className="mt-4  text-xl leading-7 text-white/80">
                تعرّف على كل مساحة داخل ميورا، واقرأ ما تقدمه قبل الانتقال
                إليها.
              </p>
            </div>

          </div>
        </div>
      </section>

      <section className="mx-auto container text-end px-6 py-16">
        <h2 className="text-6xl font-bold md:text-4xl">اكتشف نفسك بشكل أفضل</h2>
        <p className="mt-3 text-xl leading-7 text-(--color-muted)">
          أسئلة بسيطة تساعدك على فهم مشاعرك وعاداتك بشكل أوضح، وتمنحك مساحة
          للتأمل <br /> واكتشاف خطوات مناسبة لك.
        </p>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <article className="hover-lift text-end flex flex-col rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) p-6 shadow-(--shadow-card)">
            <span className="grid h-10 w-10 text-end place-items-center rounded-xl bg-(--color-accent-blue) text-(--color-primary)">
              <FaRegHeart />
            </span>
            <p className="mt-4 text-[15px] text-(--color-muted)">
              أداة تأملية • ٣–٥ دقائق
            </p>
            <h3 className="mt-2 text-2xl font-semibold">فهم حالتك المزاجية</h3>
            <p className="mt-2 flex-1 text-[18px] leading-7 text-(--color-muted)">
              خد لحظة للتأمل في مشاعرك الحالية وفهم ما قد تحتاج إليه.
            </p>
            <a
              href="#"
              className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg border border-(--color-border) px-4 py-2 text-xl font-bold transition hover:border-(--color-primary) hover:text-(--color-primary)"
            >
              ابدأ التقييم
            </a>
          </article>

          <article className="hover-lift text-end flex flex-col rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) p-6 shadow-(--shadow-card)">
            <span className="grid h-10 w-10 text-end place-items-center rounded-xl bg-(--color-accent-green) text-emerald-600">
              <FaWind />
            </span>
            <p className="mt-4 text-[15px] text-(--color-muted)">
              أداة تأملية • ٣–٥ دقائق
            </p>
            <h3 className="mt-2 text-2xl font-semibold">مستوى التوتر اليومي</h3>
            <p className="mt-2 flex-1 text-[18px] leading-7 text-(--color-muted)">
              راجع مصادر الضغط في حياتك واكتشف خطوات بسيطة للتعامل معها.
            </p>
            <a
              href="#"
              className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg border border-(--color-border) px-4 py-2 text-xl font-bold transition hover:border-(--color-primary) hover:text-(--color-primary)"
            >
              ابدأ التقييم
            </a>
          </article>

          <article className="hover-lift text-end flex flex-col rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) p-6 shadow-(--shadow-card)">
            <span className="grid h-10 w-10 text-end place-items-center rounded-xl bg-(--color-accent-purple) text-violet-600">
              <MdOutlineDarkMode />
            </span>
            <p className="mt-4 text-[15px] text-(--color-muted)">
              أداة تأملية • ٣–٥ دقائق
            </p>
            <h3 className="mt-2 text-2xl font-semibold">عادات النوم والراحة</h3>
            <p className="mt-2 flex-1 text-[18px] leading-7 text-(--color-muted)">
              تأمل في عاداتك اليومية المرتبطة بالنوم والراحة.
            </p>
            <a
              href="#"
              className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg border border-(--color-border) px-4 py-2 text-xl font-bold transition hover:border-(--color-primary) hover:text-(--color-primary)"
            >
              ابدأ التقييم
            </a>
          </article>

          <article className="hover-lift text-end flex flex-col rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) p-6 shadow-(--shadow-card)">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-(--color-accent-orange) text-orange-500">
              <LuLeaf />
            </span>
            <p className="mt-4 text-[15px] text-(--color-muted)">
              أداة تأملية • ٣–٥ دقائق
            </p>
            <h3 className="mt-2 text-2xl font-semibold">العادات والسلوكيات</h3>
            <p className="mt-2 flex-1 text-[18px] leading-7 text-(--color-muted)">
              استكشف العادات التي ترغب في فهمها أو تغييرها تدريجيًا.
            </p>
            <a
              href="#"
              className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg border border-(--color-border) px-4 py-2 text-xl font-bold transition hover:border-(--color-primary) hover:text-(--color-primary)"
            >
              ابدأ التقييم
            </a>
          </article>
        </div>
      </section>

      <section className="mx-auto container px-6 pb-24 pt-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <a
            href="content.html"
            className="rounded-lg border border-(--color-border) bg-(--color-surface) px-5 py-2.5 text-lg font-medium shadow-(--shadow-card) transition hover:border-(--color-primary) hover:text-(--color-primary)"
          >
            استكشف كل المحتوى
          </a>
          <div className="text-end">
            <h2 className=" text-5xl font-bold leading-snug ">
              خطوات صغيرة لفهم نفسك بشكل أفضل
            </h2>
            <p className="mt-3 text-lg text-(--color-muted)">
              معلومات عملية بلغة بسيطة تساعدك في مواقف الحياة اليومية.
            </p>
          </div>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          <article className="hover-zoom overflow-hidden rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
            <div className="relative aspect-4/3 overflow-hidden">
              <img
                src={image1}
                alt="دفتر وقلم بجانب نبات"
                className="h-full w-full object-cover"
              />
              <span className="absolute inset-e-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[15px] font-medium">
                فهم المشاعر
              </span>
            </div>
            <div className="p-7 text-end">
              <p className="text-[15px] text-(--color-muted)">٤ دقائق قراءة</p>
              <h3 className="mt-2 text-2xl font-semibold">
                تسمية المشاعر: خطوة أولى لفهم نفسك
              </h3>
              <p className="mt-2 text-lg leading-7 text-(--color-muted)">
                حين نعطي شعورنا اسمًا، يصبح التعامل معه أوضح وأقل إرباكًا.
              </p>
              <a
                href="#"
                className="mt-4 inline-flex flex-row-reverse items-center gap-2 text-lg font-semibold text-(--color-primary)"
              >
                اقرأ المقال
            <FaArrowLeftLong  />

              </a>
            </div>
          </article>

          <article className="hover-zoom overflow-hidden rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
            <div className="relative aspect-4/3 overflow-hidden">
              <img
                src={image1}
                alt="كتاب مفتوح وقلم على سرير"
                className="h-full w-full object-cover"
              />
              <span className="absolute inset-e-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[15px] font-medium">
                التوتر والضغط النفسي
              </span>
            </div>
            <div className="p-7 text-end">
              <p className="text-[15px] text-(--color-muted)">٥ دقائق قراءة</p>
              <h3 className="mt-2 text-2xl font-semibold">مساحة هادئة وسط ضغط اليوم</h3>
              <p className="mt-2 text-lg leading-7 text-(--color-muted)">
                خطوات عملية قصيرة تساعدك على تهدئة إيقاع يوم مزدحم.
              </p>
              <a
                href="#"
                className="mt-4 inline-flex flex-row-reverse items-center gap-2 text-lg font-semibold text-(--color-primary)"
              >
                اقرأ المقال
            <FaArrowLeftLong  />

              </a>
            </div>
          </article>

          <article className="hover-zoom overflow-hidden rounded-(--radius-card) border border-(--color-border) bg-(--color-surface) shadow-(--shadow-card)">
            <div className="relative aspect-4/3 overflow-hidden">
              <img
                src={image1}
                alt="دفتر ملاحظات على طاولة خشبية"
                className="h-full w-full object-cover"
              />
              <span className="absolute inset-e-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[15px] font-medium">
                مهارات التعامل
              </span>
            </div>
            <div className="p-7 text-end">
              <p className="text-[15px] text-(--color-muted)">٣ دقائق قراءة</p>
              <h3 className="mt-2 text-2xl font-semibold">
                التنفس الواعي في ثلاث دقائق
              </h3>
              <p className="mt-2 text-lg leading-7 text-(--color-muted)">
                تمرين بسيط يمكنك استخدامه عندما تحتاج إلى لحظة توقف.
              </p>
              <a
                href="#"
                className="mt-4 inline-flex flex-row-reverse items-center gap-2 text-lg font-semibold text-(--color-primary)"
              >
                اقرأ المقال
            <FaArrowLeftLong  />

              </a>
            </div>
          </article>
        </div>
      </section>
    </main>
  );
}
